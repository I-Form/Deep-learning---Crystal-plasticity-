import tensorflow as tf
import numpy as np

model = tf.keras.models.load_model("model_curve.h5") # Change model path & loading method here
x = np.loadtxt("strain.txt")
y_real = np.loadtxt("stress.txt")
loss = tf.keras.losses.MeanSquaredError()
loss_record = []
y_record = []
for i in range(0,199):
    input1 = np.loadtxt("./Input_80/IPF_RGB.OriMap_"+str(i)+".txt", delimiter=",")
    input2 = np.loadtxt("./Input_80/phase_RGB.phase_"+str(i)+".txt", delimiter=",")
    input = (np.reshape(input1, (1, 100, 100, 3)) + np.reshape(input2, (1, 100, 100, 3))) / 255
    y = model.predict(input)
    y_record.append(y)
    loss_record.append(loss(y_real, y))
y_record = np.array(y_record)
loss_record = np.array(loss_record)
for k in range(2):
    loss_min_idx = np.argmin(loss_record)
    loss_record = np.delete(loss_record,loss_min_idx)
    y_record = np.delete(y_record, loss_min_idx, axis=0)
loss_min_idx = np.argmin(loss_record)
y_min = y_record[loss_min_idx]
print(loss_record[loss_min_idx])
np.savetxt("12Apr.txt",y_min,delimiter="\n",fmt='%.4f') 




