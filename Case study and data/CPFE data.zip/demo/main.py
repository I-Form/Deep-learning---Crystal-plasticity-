import tensorflow as tf
from sklearn.model_selection import train_test_split
import numpy as np
import pydot
import matplotlib.pyplot as plt

NUM_OF_DATA = 200
EPOCHS = 10
BATCH = 30


def loaddata():
    data1_file = [("./Input_05/IPF_RGB.OriMap_%d.txt" % i) for i in range(NUM_OF_DATA)]
    data2_file = [("./Input_05/phase_RGB.phase_%d.txt" % i) for i in range(NUM_OF_DATA)]
    data3_file = [("./Input_20/IPF_RGB.OriMap_%d.txt" % i) for i in range(NUM_OF_DATA)]
    data4_file = [("./Input_20/phase_RGB.phase_%d.txt" % i) for i in range(NUM_OF_DATA)]
    data5_file = [("./Input_50/IPF_RGB.OriMap_%d.txt" % i) for i in range(NUM_OF_DATA)]
    data6_file = [("./Input_50/phase_RGB.phase_%d.txt" % i) for i in range(NUM_OF_DATA)]
    data7_file = [("./Input_80/IPF_RGB.OriMap_%d.txt" % i) for i in range(NUM_OF_DATA)]
    data8_file = [("./Input_80/phase_RGB.phase_%d.txt" % i) for i in range(NUM_OF_DATA)]
    data9_file = [("./Input_95/IPF_RGB.OriMap_%d.txt" % i) for i in range(NUM_OF_DATA)]
    data10_file = [("./Input_95/phase_RGB.phase_%d.txt" % i) for i in range(NUM_OF_DATA)]
    data_a = np.empty((1000, 100, 100, 3))
    data_b = np.empty((1000, 100, 100, 3))

    idx = 0
    for data1, data2 in zip(data1_file, data2_file):
        data1 = np.loadtxt(data1, delimiter=",")
        data1 = np.reshape(data1, (100, 100, 3))
        data2 = np.loadtxt(data2, delimiter=",")
        data2 = np.reshape(data2, (100, 100, 3))
        data_a[idx] = data1 / 255
        data_b[idx] = data2 / 255
        idx = idx + 1

    for data3, data4 in zip(data3_file, data4_file):
        data3 = np.loadtxt(data3, delimiter=",")
        data3 = np.reshape(data3, (100, 100, 3))
        data4 = np.loadtxt(data4, delimiter=",")
        data4 = np.reshape(data4, (100, 100, 3))
        data_a[idx] = data3 / 255
        data_b[idx] = data4 / 255
        idx = idx + 1

    for data5, data6 in zip(data5_file, data6_file):
        data5 = np.loadtxt(data5, delimiter=",")
        data5 = np.reshape(data5, (100, 100, 3))
        data6 = np.loadtxt(data6, delimiter=",")
        data6 = np.reshape(data6, (100, 100, 3))
        data_a[idx] = data5 / 255
        data_b[idx] = data6 / 255
        idx = idx + 1

    for data7, data8 in zip(data7_file, data8_file):
        data7 = np.loadtxt(data7, delimiter=",")
        data7 = np.reshape(data7, (100, 100, 3))
        data8 = np.loadtxt(data8, delimiter=",")
        data8 = np.reshape(data8, (100, 100, 3))
        data_a[idx] = data7 / 255
        data_b[idx] = data8 / 255
        idx = idx + 1

    for data9, data10 in zip(data9_file, data10_file):
        data9 = np.loadtxt(data9, delimiter=",")
        data9 = np.reshape(data9, (100, 100, 3))
        data10 = np.loadtxt(data10, delimiter=",")
        data10 = np.reshape(data10, (100, 100, 3))
        data_a[idx] = data9 / 255
        data_b[idx] = data10 / 255
        idx = idx + 1

    result_file = ['YieldStress_05.txt', 'YieldStress_20.txt', 'YieldStress_50.txt', 'YieldStress_80.txt',
                   'YieldStress_95.txt']
    result = np.zeros((1000,1))
    idx = 0
    for file in result_file:
        result[idx:idx+200,:] = np.reshape(np.loadtxt(file),(200,1))
        idx += 200
    return data_a, data_b, result

class CNNModel(tf.keras.Model):
    def __init__(self):
        super(CNNModel, self).__init__()
        self.conv1_1 = tf.keras.layers.Conv2D(32, (3,3), activation='relu', input_shape=(-1,100,100,3))
        self.maxpool1_1 = tf.keras.layers.MaxPool2D()
        self.conv1_2 = tf.keras.layers.Conv2D(64, (3,3), activation='relu')
        self.maxpool1_2 = tf.keras.layers.MaxPool2D()
        self.conv1_3 = tf.keras.layers.Conv2D(64, (3,3), activation='relu')
        self.flatten1_1 = tf.keras.layers.Flatten()
        self.dense1_1 = tf.keras.layers.Dense(32,activation='relu')

        self.conv2_1 = tf.keras.layers.Conv2D(32, (3,3), activation='relu', input_shape=(-1,100,100,3))
        self.maxpool2_1 = tf.keras.layers.MaxPool2D()
        self.conv2_2 = tf.keras.layers.Conv2D(64, (3,3), activation='relu')
        self.maxpool2_2 = tf.keras.layers.MaxPool2D()
        self.conv2_3 = tf.keras.layers.Conv2D(64, (3,3), activation='relu')
        self.flatten2_1 = tf.keras.layers.Flatten()
        self.dense2_1 = tf.keras.layers.Dense(32,activation='relu')

        self.flatten3 = tf.keras.layers.Flatten()

        self.concat = tf.keras.layers.Concatenate()
        self.dense3_1 = tf.keras.layers.Dense(16,activation='relu')
        self.dense3_2 = tf.keras.layers.Dense(1,activation='relu')


    def call(self, x):
        x1=x[0]
        x2=x[1]
        x1 = self.conv1_1(x1)
        x1 = self.maxpool1_1(x1)
        x1 = self.conv1_2(x1)
        x1 = self.maxpool1_2(x1)
        x1 = self.conv1_3(x1)
        x1 = self.flatten1_1(x1)
        x1 = self.dense1_1(x1)

        
        x2 = self.conv2_1(x2)
        x2 = self.maxpool2_1(x2)
        x2 = self.conv2_2(x2)
        x2 = self.maxpool2_2(x2)
        x2 = self.conv2_3(x2)
        x2 = self.flatten2_1(x2)
        x2 = self.dense2_1(x2)

        x = self.concat([x1,x2])
        x= self.flatten3(x)

        y = self.dense3_1(x)
        return self.dense3_2(y)

# Start
tf.keras.backend.set_floatx('float64')
Phase, IPF,result = loaddata() #load data

train_phase = Phase[:750,:,:,:]
train_IPF = IPF[:750,:,:,:]
train_result = result[:750]

test_phase = Phase[750:,:,:,:]
test_IPF = IPF[750:,:,:,:]
test_result = result[750:]
model = CNNModel()
model.compile(optimizer='adam',
              loss=tf.keras.losses.MeanSquaredError(),
              metrics=[tf.keras.metrics.RootMeanSquaredError()])
history = model.fit(x=(train_phase, train_IPF),y=train_result,epochs=EPOCHS,batch_size=BATCH, validation_data=((test_phase,test_IPF),test_result))
# tf.keras.utils.plot_model(model,'model1.png',show_shapes=True,expand_nested=True)
model.save_weights("model_after",save_format="tf")
y_pred_test = model((test_phase,test_IPF))
y_pred_train = model((train_phase,train_IPF))
y_true = test_result
result_test = np.concatenate((y_pred_test,test_result),axis=1)
result_train = np.concatenate((y_pred_train,train_result),axis=1)
np.savetxt("train_750.csv",result_train,fmt="%.4f",delimiter=",")
np.savetxt("test_250.csv",result_test,fmt="%.4f",delimiter=",")





